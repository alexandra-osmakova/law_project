<section name="map" id="map">
	<div class="container-fluid">
		<div class="col-md-6 left-block hidden-xs">
			<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A63e35b1024969d4c36c1658b1ac03ffa692b3986c87ecf55a4f77c73545c1ff0&amp;width=100%25&amp;height=100%&amp;lang=ru_RU&amp;scroll=true"></script>
		</div>
		<div class="col-md-6 right-block">
			<div class="col-md-12">
				<h2>Главный офис в г.Казань:</h2>
			</div>
			<div class="col-md-12">
				<ul>
					<li><i class="fa fa-map-marker" area-hidden="true"></i>г. Казань, ул. Проточная, 8, 2 этаж, офис 2</li>
					<li><a href="tel: 8(843) 518-89-89"><i class="fa fa-phone" area-hidden="true"></i>+7 (843) 518-89-89</a></li>
					<li><a href="mailto: 51889892@mail.ru"><i class="fa fa-envelope" area-hidden="true"></i>51889892@mail.ru</a></li>
				</ul>
			</div>
			<div class="col-md-12">
				<div class="col-md-6 col-xs-12"><h3>Или закажите обратный <br /> звонок от оператора</h3></div>
				<div class="col-md-5 col-xs-12"><button class="zay-btn open-modal"><i class="fa fa-phone"></i>Отправить заявку</button></div>
			</div>
		</div>
		<div class="col-md-6 left-block visible-xs">
			<iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A63e35b1024969d4c36c1658b1ac03ffa692b3986c87ecf55a4f77c73545c1ff0&amp;source=constructor" width="100%" height="100%" frameborder="0"></iframe>
		</div>
	</div>
</section>

<section id="footer">
	<div class="container-fluid">
		<div class="col-md-12">
			<ul class="footer-nav hidden-xs">
	            <li><a class="nav-link" href="#main">Главная</a></li>
	            <li><a class="nav-link" href="#culture">О нас</a></li>
	            <li class="dropdown dropdown-nav">
	            	<a class="dropdown-toggle" data-toggle="dropdown">Услуги</a>
		            <ul class="dropdown-menu">
		            	<li><a href="">Юридическое обслуживание</a></li>
		            	<li><a href="">Регистрация ЮЛ, ИП, филлиалов и представительств</a></li>
		            	<li><a href="">Банкротство ФЛ, ЮЛ</a></li>
		            	<li><a href="">Комплексное сопровождение бизнеса</a></li>
		            	<li><a href="">Сделки с недвижимостью</a></li>
		            	<li><a href="">Бухгалтерское обслуживание</a></li>
		            </ul>
	        	</li>
	            <li><a class="nav-link" href="#article">Статьи</a></li>
	            <li><a class="nav-link" href="#map">Контакты</a></li>
            </ul>
        </div>
        <div class="col-md-12 footer-links">
        	<h4>Подписывайтесь на нас 
        		<hr class="visible-xs" style="border: 0 !important; margin: 5px 0" />
        		<a href="#"><i class="fa fa-facebook" area-hidden="true"></i></a>
        		<a href="#"><i class="fa fa-twitter" area-hidden="true"></i></a>
        		<a href="#"><i class="fa fa-vk" area-hidden="true"></i></a>
        		<a href="#"><i class="fa fa-telegram" area-hidden="true"></i></a>
        	</h4>
        </div>
        <div class="col-md-12">
        	<div class="col-md-4">
        		<h3><a class="nav-link" href="#main">&copy; 2018 ООО «ЮРБИЗНЕСГРУП»</a></h3>
        	</div>
        	<div class="col-md-4">
        		<h3><a href="#">Политика конфиденциальности</a></h3>
        	</div>
        	<div class="col-md-4">
        		<h3>Разработка сайтов <a style="color: #00b4f7" href="http://itkluch.ru">ITKluch.ru</a></h3>
        	</div>
        </div>
    </div>
</section>


<div class="modal-overlay">
  <div class="modal">

    <a class="close-modal">
      <svg viewBox="0 0 20 20">
        <path fill="#000000" d="M15.898,4.045c-0.271-0.272-0.713-0.272-0.986,0l-4.71,4.711L5.493,4.045c-0.272-0.272-0.714-0.272-0.986,0s-0.272,0.714,0,0.986l4.709,4.711l-4.71,4.711c-0.272,0.271-0.272,0.713,0,0.986c0.136,0.136,0.314,0.203,0.492,0.203c0.179,0,0.357-0.067,0.493-0.203l4.711-4.711l4.71,4.711c0.137,0.136,0.314,0.203,0.494,0.203c0.178,0,0.355-0.067,0.492-0.203c0.273-0.273,0.273-0.715,0-0.986l-4.711-4.711l4.711-4.711C16.172,4.759,16.172,4.317,15.898,4.045z"></path>
      </svg>
    </a><!-- close modal -->

    <div class="modal-content">
      <h3 class="hidden-xs">Оставьте Ваши контактные данные <br /> и мы вам перезвоним</h3>
      <h3 class="visible-xs">Оставьте Ваши <br /> контактные данные <br /> и мы вам перезвоним</h3>
    	<form action="mail/mail.php" method="post">
    		<input type="text" name="name" placeholder="Введите имя" />
    		<input type="tel" name="phone" placeholder="Введите телефон" required />
    		<input type="text" name="mail" placeholder="Введите E-Mail" />
    		<select name="usluga">
    			<option selected disabled value="Выберите услугу">Выберите услугу</option>
    			<option value="Юридическое обслуживание">Юридическое обслуживание</option>
    			<option value="Регистрация ЮЛ, ИП, филлиалов и представительств">
    			Регистрация ЮЛ, ИП, филлиалов и представительств</option>
    			<option value="Банкротство ФЛ, ЮЛ">Банкротство ФЛ, ЮЛ</option>
    			<option value="Комплексное сопровождение бизнеса">Комплексное сопровождение бизнеса</option>
    			<option value="Сделки с недвижимостью">Сделки с недвижимостью</option>
    			<option value="Бухгалтерское обслуживание">Бухгалтерское обслуживание</option>
    		</select>
    		<input class="sbmt-btn" type="submit" name="submit" value="Оставить заявку" />
    	</form>
    </div><!-- content -->
    
  </div><!-- modal -->
</div><!-- overlay -->

<script type="text/javascript" src="js/wow.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
<script type="text/javascript" src="js/swiper.min.js"></script>
<script src="js/jquery.spincrement.min.js"></script>
<script type="text/javascript">
$(".spincrement").spincrement();

$(window).scroll(function(){
    if ($(window).scrollTop() > 100) {
        $('.navbar').css('top',"-70px").css('box-shadow',"0 0 15px rgba(23, 67, 139, 0.4)");
    }
    else {
        $('.navbar').css('top',"0").css('box-shadow',"none");
    }
});

$('.search-ico').click(function(){
	if($('.navbar-top form').hasClass('active')){
		$('.navbar-top form').removeClass('active').css('opacity', "0").css('z-index', "-1");
	}
	else{
		$('.navbar-top form').addClass('active').css('opacity', "1").css('z-index', "1");
	}
});

	    var swiper = new Swiper('#main .swiper-container', {
	      pagination: {
	        el: '.swiper-pagination.main-pagination',
	        clickable: true,
	      },
	      autoplay: {
	        delay: 8000,
	        disableOnInteraction: false,
	      },
	      loop: true,
	      navigation: {
	        nextEl: '.swiper-button-next.main-next',
	        prevEl: '.swiper-button-prev.main-prev',
	      },
	    });
	    
	if( window.screen.width <= 600 ){
	    $('#ras-form').removeClass('fadeInRight');
	    $('#ras-form').addClass('fadeInUp');
      }
      else if( window.screen.width <= 800 ){
	  }
      else{
      };
      
      $('.show-li').click(function(){
      	if($('.show-li').hasClass('active')){
	      	$('.show-li').text('Ещё ...').removeClass('active');
	      	$('.hide-li').css("display",'none');
      	}
      	else{
	      	$('.show-li').text('Скрыть ...').addClass('active');
	      	$('.hide-li').css("display",'block');
      	}
      });
      
      $('#list button').click(function(){
		if($('#services-modal').hasClass('active')){
			$('#services-modal').css('opacity',"0").css('z-index',"-1").removeClass('active');
			$('#services-modal .modal-container').css('transform', "scale(0.5,0.5)");
		    $('.modal-header h3').empty();
		    $('table tr').removeClass('nameFirst');
		}
		else{
			$('#services-modal').css('opacity',"1").css('z-index',"10000").addClass('active');
			$('#services-modal .modal-container').css('transform',"scale(1,1)");
			var name = $(this).parent();
			var nameFirst = $(name).parent();
			nameFirst.addClass('nameFirst')
			$('.modal-header h3').text($('.nameFirst > td:first-child').text());
		}
	});
	$('.services-close-modal').click(function(){
			$('#services-modal').css('opacity',"0").css('z-index',"-1").removeClass('active');
			$('#services-modal .modal-container').css('transform', "scale(0.5,0.5)");
		    $('.modal-header h3').empty();
		    $('table tr').removeClass('nameFirst');
	});
		$(document).mouseup(function (e){ // событие клика по веб-документу
		var div = $(".modal-container, .modal"); // тут указываем ID элемента
		if (!div.is(e.target) // если клик был не по нашему блоку
		    && div.has(e.target).length === 0) { // и не по его дочерним элементам
			$('#services-modal').css('opacity',"0").css('z-index',"-1").removeClass('active');	
			$('#services-modal .modal-container').css('transform', "scale(0.5,0.5)");
		    $('.modal-header h3').empty();
		    $('table tr').removeClass('nameFirst');
		    $('.modal-overlay').removeClass('active');
		    $('.modal').removeClass('active');
		}
	});
            $(document).keydown(function(eventObject){
                if (eventObject.which == 27){
					$('#services-modal').css('opacity',"0").css('z-index',"-1").removeClass('active');	
					$('#services-modal .modal-container').css('transform', "scale(0.5,0.5)");
				    $('.modal-header h3').empty();
		    		$('table tr').removeClass('nameFirst');
		    		$('.modal-overlay').removeClass('active');
		    		$('.modal').removeClass('active');
                }
            });
</script>
</body>
</html>