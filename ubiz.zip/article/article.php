<!DOCTYPE html>
<html>
<head>
	<title>Статья | Юрбизнесгруп</title>
	<meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, width=device-width, user-scalable=no">
	<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Old+Standard+TT:400,700&amp;subset=cyrillic" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=cyrillic" rel="stylesheet">
	<link rel="shortcut icon" type="image/png" href="../img/favicon.png">
	<link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="../css/animate.css">
	<link rel="stylesheet" type="text/css" href="../css/fonts.css">
	<link rel="stylesheet" type="text/css" href="../css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../css/modal.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">	
	<script src="https://api-maps.yandex.ru/1.1/index.xml" type="text/javascript"></script>
	<script type="text/javascript">
	    // Создает обработчик события window.onLoad
	    YMaps.jQuery(function () {
	        // Создает экземпляр карты и привязывает его к созданному контейнеру
	        var map = new YMaps.Map(YMaps.jQuery("#YMapsID")[0]);

	        // Устанавливает начальные параметры отображения карты: центр карты и коэффициент масштабирования
	        map.setCenter(new YMaps.GeoPoint(49.040005, 55.800287 ), 5);

function myLayout(context, map, owner) {
    var element = YMaps.jQuery('<div style="width: 40px; height: 40px; background-image: url(../img/point.png);background-size: contain;background-position: center center;background-repeat: no-repeat;"></div>');
    this.onAddToParent = function (parentNode) {
        element.appendTo(parentNode);
    };
    this.onRemoveFromParent = function () {
        element.remove();
    };
    this.update = function () {};
    this.getOffset = function () { return new YMaps.Point(-20, -40); };
    this.getRootNodes = function() { return element; };
	
};
var myStyle = new YMaps.Style();
myStyle.iconStyle = new YMaps.IconStyle(new YMaps.LayoutTemplate(myLayout));
var myPlacemark = new YMaps.Placemark(map.getCenter(), {style: myStyle});
myPlacemark.name = ":p";
map.addOverlay(myPlacemark);
	    })
	</script>
</head>
<body>
	<div class="navbar">
		<div class="container">
			<div class="navbar-top">
				<div class="nav-logo">ООО «ЮРБИЗНЕСГРУП»</div>
				<div class="city">Ваш город: <span>Казань</span></div>
		          <div class="search-form" id="nav-collapse3">
		            <form class="navbar-form navbar-right" role="search">
		              <div class="form-group">
		                <input type="text" class="form-control" placeholder="Search" />
		              </div>
		              <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
		            </form>
		          </div>
		        <div class="right-block">
					<div class="nav-number"><a href="tel: +7(843)518-89-89"><i class="fa fa-phone"></i> +7 (843) 518-89-89</a></div>
		            <div class="search-btn">
		              <a class="search-ico"><i class="fa fa-search"></i></a>
		            </div>
		        </div>
			</div>
			<hr />
			<div class="navbar-botom">
				<ul>
					<li><a href="#culture">О нас</a></li>
					<li><a href="services">Услуги</a></li>
					<li><a href="#article">Статьи</a></li>
					<li><a href="#map">Контакты</a></li>
					<li><a href="">Регистрация</a> | <a href="">Вход</a></li>
				</ul>
			</div>
		</div>
	</div>

    <section id="main">
    	<div class="swiper-container">
	    		<div class="swiper-slide slide-article">
					<div class="overlay">
						<div class="container" style="text-align: center;">
			    			<h1>О порядке налогообложения субсидий получаемых
							<br />из центра занятости на развитие бизнеса</h1>
			    			<a href="#" class="more-btn all-btn"><svg style="transform: rotate(180deg);margin-right: 15px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 17 12" width="17" height="12">
	<style>
		tspan { white-space:pre }
		.shp0 { fill: #fff } 
	</style>
	<path id="Forma 1 копия" class="shp0" d="M11.38,1.04c-0.23,-0.2 -0.61,-0.2 -0.84,0c-0.23,0.2 -0.23,0.53 0,0.72l4.28,3.71h-14.14c-0.33,0 -0.59,0.23 -0.59,0.51c0,0.29 0.26,0.52 0.59,0.52h14.14l-4.28,3.7c-0.23,0.2 -0.23,0.53 0,0.73c0.24,0.2 0.62,0.2 0.84,0l5.3,-4.59c0.24,-0.2 0.24,-0.53 0,-0.72z" />
</svg> Все статьи</a>
			    		</div>
			    	</div>
				</div>
	    	<div class="swiper-button-prev main-prev"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 27 44'><path d='M0,22L22,0l2.1,2.1L4.2,22l19.9,19.9L22,44L0,22L0,22L0,22z' fill='#fff'/></svg></div>
	    	<div class="swiper-button-next main-next"><svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 27 44'><path d='M27,22L27,22L5,44l-2.1-2.1L22.8,22L2.9,2.1L5,0L27,22L27,22z' fill='#fff'/></svg></div>
    	</div>
    </section>

    <section id="text">
    	<div class="container">
    		<div class="col-md-8">
    			<h3>О порядке налогообложения субсидий <br /> получаемых из центра занятости на <br /> развитие бизнеса</h3>
    			<p>Всем известно, что для открытия собственного дела необходим хотя бы какой-то начальный капитал. 
Однако зачастую бывает так, что у человека нет средств для старта, но есть идея, причем, как говорится, идея
на миллион! Что же делать в таком случае? Влезать в кредиты или занимать у знакомых, памятуя о том, как долги портят отношения? К счастью, сейчас действует программа финансовой поддержки безработных для создания ими своего бизнеса, и в рамках данной программы государство не просто кредитует средства начинающим предпринимателям. Финансовая поддержка осуществляется в форме безвозмездной субсидии, и возвращать выделенные средства при соблюдении всех условий Вам не придется! Кроме того надо сказать, что в последнее время налогообложение субсидий существенно изменилось и причем в лучшую сторону, что заметно облегчило жизнь начинающим бизнесменам. </p>
				<h4>Условия субсидирования</h4>
				<p>Итак, как получить средства для создания своего бизнеса, и в каком порядке потом проходит налогообложение субсидий, выплаченных из муниципального или федерального бюджета?</p>

<p>Во-первых, надо сказать, что происходит получение субсидии в центре занятости, а, следовательно, Вы должны состоять там на учете как безработный совершеннолетний гражданин Российской Федерации, а это в свою очередь значит отмечаться два раза в месяц у своего инспектора. Именно у инспектора поинтересуйтесь по поводу субсидии на открытие своего дела, и Вам предложат пройти собеседование и заполнить тест. Затем от Вас потребуется бизнес-план. Если у Вас нет опыта и знаний в данной сфере, не отчаивайтесь! В том же центре занятости часто проводятся различные бизнес-курсы. Там Вам расскажут, какие отрасли бизнеса сейчас актуальны, какие ниши пустуют, и как правильно и подробно построить бизнес-план. Ведь очень важно потом заинтересовать своим проектом комиссию, которая будет принимать решение о субсидировании в Ваше дело. Возможно, Вам стоит прибегнуть к такому виду услуг, как юридическая консультация для того, чтобы быть в курсе возможных подводных камней. Сейчас приоритетными сферами для финансовой поддержки считаются передовые технологии и сельское хозяйство. А также значительным фактором является то количество людей, которых Вы сможете в дальнейшем обеспечить рабочими местами.</p>

<p>Очень важно помнить, что нельзя регистрировать свою фирму (ИП или ООО) до того, как Ваш бизнес-план одобрят! Ведь таким образом Вы автоматически перестанете считаться безработным, а значит, и претендовать
на субсидию не сможете!</p>

<p>Но вот бизнес-план готов. Вы передали его инспектору, а он отправил по цепочке наверх. Через какое время наконец-то пришло "добро". Вы зарегистрировали фирму и получили субсидию. О какой сумме идет речь, 
и в какой мере она облагается налогом? </p>
				<h4>Налогообложение субсидий</h4>
				<p>В настоящий момент установленный размер финансовой поддержки самозанятости населения составляет 
58800 рублей (стоит уточнить, что в некоторых субъектах Федерации, например, в Москве, субсидия может быть больше). Иными словами, Вы получаете максимальное пособие по безработице за целый год. Это довольно умеренная сумма, но для открытия небольшого дела ее вполне может быть достаточно. Впрочем, до 2011 года
от этих средств тут же необходимо было бы выплатить Налог на прибыль или Налог на доходы физических лиц
в зависимости от организационно-правовой формы Вашей фирмы. То есть часть денег тотчас возвращалась
в бюджет, будучи нереализованной. Но 11 марта 2011 года с вступлением в силу Федерального закона от 07.03.2011 N 23-ФЗ в порядок налогообложения субсидий были внесены значительные коррективы. Теперь сумма субсидии включается в доходы лишь по мере расходования этих средств. Такая система действует в течение двух лет с получения субсидии, и если по окончании этого срока сумма финансовой поддержки все еще будет превышать сумму расходов, вот тогда придется включить остаток субсидии в доходы и заплатить с него налог. 
Эти изменения распространяются на все соответствующие случаи с начала 2011 года. 

<p>Рациональные изменения, которые вносятся в налогообложение субсидий, подтверждают то, что у малого бизнеса в России есть будущее. Более того государство показывает, что ему выгодно помогать начинающим предпринимателям, и оно идет им навстречу. 
</p>
<h4>В услуги "Юрбизнесгруп" также входит:</h4>
<ul>
	<li>Оформление лицензии на реализацию алкогольной продукции</li>
    <li>Преобразование фирм</li>
</ul>
<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
<div class="links">
	<div class="prev-article"><svg style="transform: rotate(90deg);margin-right: 10px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="12" height="12">
	<style>
		tspan { white-space:pre }
		.shp0 { fill: #000 } 
	</style>
	<g id="Layer">
		<path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" />
	</g>
</svg>Предыдущая статья</div>
	<div class="all-article">Все статьи</div>
	<div class="next-article">Следующая статья<svg style="transform: rotate(-90deg);margin-left: 10px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="12" height="12">
	<style>
		tspan { white-space:pre }
		.shp0 { fill: #000 } 
	</style>
	<g id="Layer">
		<path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" />
	</g>
</svg></div>
</div>
    		</div>
    		<div class="col-md-4">
    			<h5>Последние статьи</h5>
    			<div class="col-md-12">
    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
    				<h6>Порядок регистрации фирмы</h6>
    				<p>Первостепенная задача – это составление действующего Устава фирмы, который должен быть оформлен в строгом соответствии с... </p>
    			</div>
    			<div class="col-md-12">
    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
    				<h6>Порядок регистрации фирмы</h6>
    				<p>Первостепенная задача – это составление действующего Устава фирмы, который должен быть оформлен в строгом соответствии с... </p>
    			</div>
    			<div class="col-md-12">
    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
    				<h6>Порядок регистрации фирмы</h6>
    				<p>Первостепенная задача – это составление действующего Устава фирмы, который должен быть оформлен в строгом соответствии с... </p>
    			</div>
    			<div class="col-md-12 social">
    				<h5>Поделиться в социальных сетях:</h5>
    				<i class="fa fa-vk"></i><i class="fa fa-facebook"></i><i class="fa fa-twitter"></i>
    			</div>
    		</div>
    	</div>
    </section>

<?php
require('../footer.php');
?>