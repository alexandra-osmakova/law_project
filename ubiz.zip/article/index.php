<!DOCTYPE html>
<html>
<head>
	<title>Статьи | Юрбизнесгруп</title>
	<meta charset="utf-8">
    <meta name="viewport" content="initial-scale=1, width=device-width, user-scalable=no">
	<script src="http://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Old+Standard+TT:400,700&amp;subset=cyrillic" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700&amp;subset=cyrillic" rel="stylesheet">
	<link rel="shortcut icon" type="image/png" href="../img/favicon.png">
	<link rel="stylesheet" type="text/css" href="../css/font-awesome.css">
	<link rel="stylesheet" type="text/css" href="../css/animate.css">
	<link rel="stylesheet" type="text/css" href="../css/fonts.css">
	<link rel="stylesheet" type="text/css" href="../css/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="../css/modal.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">	
	<script src="https://api-maps.yandex.ru/1.1/index.xml" type="text/javascript"></script>
	<script type="text/javascript">
	    // Создает обработчик события window.onLoad
	    YMaps.jQuery(function () {
	        // Создает экземпляр карты и привязывает его к созданному контейнеру
	        var map = new YMaps.Map(YMaps.jQuery("#YMapsID")[0]);

	        // Устанавливает начальные параметры отображения карты: центр карты и коэффициент масштабирования
	        map.setCenter(new YMaps.GeoPoint(49.040005, 55.800287 ), 5);

function myLayout(context, map, owner) {
    var element = YMaps.jQuery('<div style="width: 40px; height: 40px; background-image: url(../img/point.png);background-size: contain;background-position: center center;background-repeat: no-repeat;"></div>');
    this.onAddToParent = function (parentNode) {
        element.appendTo(parentNode);
    };
    this.onRemoveFromParent = function () {
        element.remove();
    };
    this.update = function () {};
    this.getOffset = function () { return new YMaps.Point(-20, -40); };
    this.getRootNodes = function() { return element; };
	
};
var myStyle = new YMaps.Style();
myStyle.iconStyle = new YMaps.IconStyle(new YMaps.LayoutTemplate(myLayout));
var myPlacemark = new YMaps.Placemark(map.getCenter(), {style: myStyle});
myPlacemark.name = ":p";
map.addOverlay(myPlacemark);
	    })
	</script>
</head>
<body>
		<div class="navbar">
		<div class="container">
			<div class="navbar-top">
				<div class="nav-logo">ООО «ЮРБИЗНЕСГРУП»</div>
				<div class="city">Ваш город: <span>Казань</span></div>
		          <div class="search-form" id="nav-collapse3">
		            <form class="navbar-form navbar-right" role="search">
		              <div class="form-group">
		                <input type="text" class="form-control" placeholder="Search" />
		              </div>
		              <button type="submit" class="btn btn-danger"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
		            </form>
		          </div>
		        <div class="right-block">
					<div class="nav-number"><a href="tel: +7(843)518-89-89"><i class="fa fa-phone"></i> +7 (843) 518-89-89</a></div>
		            <div class="search-btn">
		              <a class="search-ico"><i class="fa fa-search"></i></a>
		            </div>
		        </div>
			</div>
			<hr />
			<div class="navbar-botom">
				<ul>
					<li><a href="../about">О нас</a></li>
					<li><a href="../services">Услуги</a></li>
					<li><a class="active" href="../article">Статьи</a></li>
					<li><a href="../contact">Контакты</a></li>
					<li><a href="">Регистрация</a> | <a href="">Вход</a></li>
				</ul>
			</div>
		</div>
	</div>

    <section id="main">
    	<div class="swiper-container">
	    		<div class="swiper-slide slide-article">
					<div class="overlay">
						<div class="container">
			    			<h1>Статьи</h1>
			    			<p>Наша компания оказывает широкий спектр услуг как для физических, 
								<br />так и для юридических лиц. Рекомендуем Вам сначала обратиться за бесплатной
								<br />консультацией.</p>
			    			<a href="#" class="more-btn">Получить бесплатную консультацию</a>
			    		</div>
			    	</div>
				</div>
    	</div>
    </section>

    <section id="articles">
    	<div class="container">
    		<div class="categories">
				<ul class="category-list">
					<li>По хронологии</li>
					<li>По названию</li>
					<li>По просмотрам</li>
					<li>Выбрать тег</li>
				</ul>
				<ul class="article-number">
					<li><svg class="arrow-left" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="10" height="10"><style>tspan { white-space:pre }.shp0 { fill: #282828 }</style><g id="Layer"><path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" /></g></svg></li>
					<li>1</li>
					<li>...</li>
					<li>181</li>
					<li>182</li>
					<li>183</li>
					<li>184</li>
					<li>185</li>
					<li><svg class="arrow-right" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="10" height="10"><style>tspan { white-space:pre }.shp0 { fill: #282828 }</style><g id="Layer"><path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" /></g></svg></li>
				</ul>
    		</div>
    		<div class="article-list">
    			<div class="row">
	    			<div class="col-md-6">
	    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
	    				<h3>О порядке налогообложения субсидий получаемых из центра занятости на развитие бизнеса</h3>
	    				<p>Всем известно, что для открытия собственного дела необходим хотя бы какой-то начальный капитал. Однако зачастую бывает так, что у человека нет средств для старта, но есть идея, причем, как говорится, идея на миллион! Что же делать в таком случае? </p>
	    			</div>
	    			<div class="col-md-6">
	    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
	    				<h3>ПРОЦЕСС ПОДГОТОВКИ И СДАЧИ ОТЧЕТНОСТИ ЮРИДИЧЕСКОГО ЛИЦА</h3>
	    				<p>Одной из важнейших проблем в деятельности юридических лиц является подготовка и сдача отчетности за установленные периоды времени. Данная задача всецело лежит на бухгалтерии юридического лица. Роль, которую выполняет подготовка и сдача отчетности в современном бизнесе, трудно переоценить, ведь таким образом подводится итог проделанной работы, оценивается коэффициент полезного действия, открываются все прибыли и убытки. </p>
	    			</div>
	    		</div>
    			<div class="row">
	    			<div class="col-md-6">
	    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
	    				<h3>ПОРЯДОК РЕГИСТРАЦИИ ФИРМЫ</h3>
	    				<p>Первостепенная задача – это составление действующего Устава фирмы, который должен быть оформлен в строгом соответствии с действующим законодательством РФ. В противном случае проблемы могут возникнуть уже в первые месяцы ведения деятельности, что может привести к выплате значительных штрафов и даже ликвидации предприятия.  </p>
	    			</div>
	    			<div class="col-md-6">
	    				<div class="date">27.08.2018, 20:25</div><div class="shows"></div><div class="hashtag"></div>
	    				<h3>НОВЫЙ ЗАКОНОПРОЕКТ ОЗНАМЕНУЕТ ИЗМЕНЕНИЕ В ПРИЕМЕ СТРАХОВЫХ ВЗНОСОВ, ЗАНИМАТЬСЯ КОТОРЫМИ ТЕПЕРЬ БУДЕТ ФНС.</h3>
	    				<p>Несколько лет ФНС была освобождена от сбора социальных взносов, однако с 2017 года эта функция вновь возвращается к ней. Для того, чтобы несколько облегчить ведомству работу, «налоговикам» будет... </p>
	    			</div>
	    		</div>			
    		</div>
    		<div class="number">
				<ul class="article-number">
					<li><svg class="arrow-left" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="10" height="10"><style>tspan { white-space:pre }.shp0 { fill: #282828 }</style><g id="Layer"><path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" /></g></svg></li>
					<li>1</li>
					<li>...</li>
					<li>181</li>
					<li>182</li>
					<li>183</li>
					<li>184</li>
					<li>185</li>
					<li><svg class="arrow-right" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 117 63" width="10" height="10"><style>tspan { white-space:pre }.shp0 { fill: #282828 }</style><g id="Layer"><path id="Layer" class="shp0" d="M115.3,1.6c-1.6,-1.6 -4.2,-1.6 -5.8,0l-51,51.1l-51.1,-51.1c-1.6,-1.6 -4.2,-1.6 -5.8,0c-1.6,1.6 -1.6,4.2 0,5.8l53.9,53.9c0.8,0.8 1.8,1.2 2.9,1.2c1,0 2.1,-0.4 2.9,-1.2l53.9,-53.9c1.7,-1.6 1.7,-4.2 0.1,-5.8z" /></g></svg></li>
				</ul>
			</div>
    	</div>
    </section>

<?php
require('../footer.php');
?>